export const PRODUCT_CATEGORIES = ["Cosmetics", "Kids", "HealthCare"];
