import React from "react";
import AdminLayout from "../Layouts/AdminLayout";

const Dashboard = () => {
  return <AdminLayout>Dashboard</AdminLayout>;
};

export default Dashboard;
