import React from "react";

const NoResultPage = () => {
  return (
    <div>
      <div className=" h-56 flex justify-center items-center text-6xl">
        No Products found 🤔🤔
      </div>
    </div>
  );
};

export default NoResultPage;
