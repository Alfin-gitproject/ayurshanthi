export const key = process.env.REACT_APP_RAZORPAY_SECRET_ID;
